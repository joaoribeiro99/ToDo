// Adds the done class for the todo items
$("ul").on('click', 'li', function () {
    $(this).toggleClass("done");
});

// Adds a new item to the todo list
$("input").keyup(function (event) {
    if(event.which===13){
        var value = $(this).val();
        $("ul").append("<li><span>"+"<i class='fas fa-trash-alt'></i>"+"</span>" + value + "</li>");
        $("input").val('');}
    }).keyup();

 // Removes the unwanted item by clicking the X
$("ul").on("click", "span", function(e){
    $(this).parent().fadeOut(500, function(){
        $(this).remove();   // Note that this (this) is no longer the span but the li as we already had gone up.
                            // If I had used .parent() before the .remove() I would had deleted the whole ul.
    });
    // The function event.stopPropagation() is used to prevent the action going up in the hierarchi
    e.stopPropagation();
});

$(".fa-pencil-alt").hover(function(){
    $("input").slideDown("slow", "swing");
});

// $("li").hover(function () {
//     $(this["span"]).slideToggle("slow", "swing");
// });